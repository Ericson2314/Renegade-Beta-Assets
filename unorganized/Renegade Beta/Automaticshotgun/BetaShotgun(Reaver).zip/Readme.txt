This is the Beta Shotgun that I have recreated.

Some texture parts are from the Sole Survivor mod.
(The clip)
Credits to them!

If you have any comments or want to mod it please contact me first.
If you do modify it please credit me!

To install unzip all the contents to your data folder.

Reaver11