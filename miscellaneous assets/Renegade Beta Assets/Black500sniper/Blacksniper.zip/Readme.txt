This is the old 500 sniper that I have recreated.
It is fully textured and animated! It also has an animated powerup!

It should contain the following files:
f_ga_snip_relod
f_gm_snip
f_cm_snip
p_snip
w_snip
w_snip_B

The gmax files for this weapon will be released in a new version of the big beta pack.

The old ones download link:
http://www.renz0r.net/Renegade_beta_assets_pack_1.0.zip

If you want to edit this sniper wait for the new beta pack. If you cant wait you may do it but please credit me for making this sniper.

-Reaver11