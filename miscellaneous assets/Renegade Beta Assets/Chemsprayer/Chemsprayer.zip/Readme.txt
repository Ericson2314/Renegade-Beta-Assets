This is the old chemsprayer that I have recreated.
It contains 5 w3d's and textures (Including reload and powerupmodels!)

You may use this model in your game. If you are thrilled to modify it wait until the next version of the Renegade beta pack it will contain the gmax files.

-Reaver11