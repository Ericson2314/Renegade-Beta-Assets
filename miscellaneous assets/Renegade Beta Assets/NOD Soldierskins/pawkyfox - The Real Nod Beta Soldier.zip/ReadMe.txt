Beta Nod Soldier Skin by pawkyfox

August, 24, 2009

This is Nod soldier skin based on first ever promo screenshots from the game. Much closer to the Nod soldier concept artwork for Renegade and much closer to early box artwork.

New logos, numbers, new longer full kneepads, dark clothing, more posckets, new belts and a many many changes including the Beta facemask!!!

Instructions: Extract the .dds file and copy paste it into your Data folder where Ren is installed.

enjoy the skin!

pawkyfox