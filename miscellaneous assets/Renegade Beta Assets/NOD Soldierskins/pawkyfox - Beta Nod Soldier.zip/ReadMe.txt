Beta Nod Soldier Skin by pawkyfox

This is Nod soldier skin based on first ever screenshots from the game that featured in PC Gamer magazine in Oct 1999. Much closer to the Nod soldier concept artwork for Renegade.

New logos, numbers, flag patches, new longer full kneepads.

Instructions: Extract the .dds file and copy paste it into your Data folder where Ren is installed.

pawkyfox