This is the Beta Pistol that I have recreated.
Its not perfect but its the best at the moment.

A texture fix will be made.
But I thought it is nice sharing it now.

To install unzip all content to your data folder.
(You may exclude preview.jpg)

If you have any comments or want to mod it please contact me first.
If you do modify it please credit me!

Reaver11